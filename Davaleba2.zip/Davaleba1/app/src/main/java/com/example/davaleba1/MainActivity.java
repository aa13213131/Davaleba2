package com.example.davaleba1;

import android.app.Activity;

public class MainActivity extends Activity {
}
