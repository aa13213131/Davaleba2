import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.davaleba1.R

class RecyclerViewFragment : Fragment(R.layout.view_pager_item) {

    companion object {
        private const val ARG_ITEMS = "items"

        fun newInstance(items: List<String>): RecyclerViewFragment {
            val fragment = RecyclerViewFragment()
            val args = Bundle()
            args.putStringArrayList(ARG_ITEMS, ArrayList(items))
            fragment.arguments = args
            return fragment
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerView)
        val items = arguments?.getStringArrayList(ARG_ITEMS) ?: listOf()

        recyclerView.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.adapter = RecyclerViewAdapter(items)
    }
}
