import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

    private val pageData = listOf(
        listOf("Item 1", "Item 2", "Item 3", "Item 4"),
        listOf("Item 5", "Item 6", "Item 7", "Item 8"),
        listOf("Item 9", "Item 10", "Item 11", "Item 12")
    )

    override fun getItemCount(): Int = pageData.size

    override fun createFragment(position: Int): Fragment {
        return RecyclerViewFragment.newInstance(pageData[position])
    }
}

